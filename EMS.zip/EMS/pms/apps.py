from django.apps import AppConfig


class PmsConfig(AppConfig):
    name = 'pms'
